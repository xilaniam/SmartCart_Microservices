create view pg_config(name, setting) as
SELECT name,
       setting
FROM pg_config() pg_config(name, setting);

alter table pg_config
    owner to admin;

