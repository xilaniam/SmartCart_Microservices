create view pg_stat_wal(wal_records, wal_fpi, wal_bytes, wal_buffers_full, stats_reset) as
SELECT wal_records,
       wal_fpi,
       wal_bytes,
       wal_buffers_full,
       stats_reset
FROM pg_stat_get_wal() w(wal_records, wal_fpi, wal_bytes, wal_buffers_full, stats_reset);

alter table pg_stat_wal
    owner to admin;

grant select on pg_stat_wal to public;

